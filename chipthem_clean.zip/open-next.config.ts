// opennext.config.ts

import { defineCloudflareConfig } from "@opennextjs/cloudflare/config";

export default defineCloudflareConfig({
    // Pass the externals array directly in the root object
    // This tells the underlying bundler to ignore this module
    
});