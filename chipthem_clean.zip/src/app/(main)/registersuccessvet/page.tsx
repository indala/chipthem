import RegistrationSuccess from "@/components/registrationsuccess";

export default function page(){
    return (
        <div>
            <RegistrationSuccess type={"vet"}/>
        </div>
    )
}