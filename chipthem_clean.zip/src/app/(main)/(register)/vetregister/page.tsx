import VetRegisterHero from "@/components/VetRegisterHero"
import VeterinaryClinicRegistration from "@/components/VeterinaryClinicRegistration"

const page = () => {
  return (
    <div>
        <VetRegisterHero />
        <VeterinaryClinicRegistration />
    </div>
  )
}
export default page