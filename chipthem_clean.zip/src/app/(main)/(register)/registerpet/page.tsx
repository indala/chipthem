import RegisterHero from "@/components/RegisterHero"
import RegisterMenu from "@/components/RegisterMenu"

const page = () => {
  return (
    <div>
        <RegisterHero />
        <RegisterMenu />
    </div>
  )
}

export default page