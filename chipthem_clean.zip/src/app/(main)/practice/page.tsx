import React from 'react'

const page = () => {
  return (
    <>
    <div className="p-64 text-center" >hello</div>
    <div className="m-16 flex gap-x-4 bg-white p-6 shadow-lg outline outline-black/5 dark:bg-slate-800 dark:shadow-none dark:-outline-offset-1 dark:outline-white/10">
        <div className="text-xl font-medium">hello mohan</div>
        <div>here is your output</div>
    </div>
    </>
   
  )
}

export default page