export declare function loadEnvConfig(): void;
