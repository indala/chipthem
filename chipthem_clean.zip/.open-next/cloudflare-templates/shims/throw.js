throw "OpenNext shim";
export default {};
